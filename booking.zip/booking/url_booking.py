from  django.conf.urls import url,include
from booking import views


urlpatterns = [
     url(r'^$', views.add,name='add'),
 ]