from django.shortcuts import render
from booking.models import Booking
def add(request):
    if request.method == "POST":
        obj = Booking()

        obj.flatno = request.POST.get("name")
        obj.memid = 5
        obj.date = request.POST.get("Date")
        obj.name = request.POST.get("name")
        obj.purpose = "wedding"
        obj.fdate = request.POST.get("Date")
        obj.ftime = request.POST.get("time")
        obj.days = request.POST.get("Days")


        obj.save()
    return render(request,'booking/booking.html')