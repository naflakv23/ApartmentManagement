from django.conf.urls import url
from apartmentadd import views
urlpatterns = [

    url('^$',views.add,name='add'),
    url('^viewaprt/',views.viewaprt,name='viewaprt'),
]
