from django.shortcuts import render
from apartmentadd.models import Addapartment
# Create your views here.
def add(request):
    if request.method == "POST":
        obj = Addapartment()

        obj.aptname = request.POST.get("aname")
        obj.address = request.POST.get("add")
        obj.flatcount = request.POST.get("flat")
        obj.mailid = request.POST.get("email")
        obj.contact = request.POST.get("contact")
        obj.save()
    return render(request,'apartmentadd/addapt.html')
def viewaprt(request):
    objlist = Addapartment.objects.all()
    context={
        'objval': objlist,
    }
    return render(request, 'apartmentadd/view2apartment.html',context)