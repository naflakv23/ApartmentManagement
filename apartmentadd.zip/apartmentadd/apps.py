from django.apps import AppConfig


class ApartmentaddConfig(AppConfig):
    name = 'apartmentadd'
