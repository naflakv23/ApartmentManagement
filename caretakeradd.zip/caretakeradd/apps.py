from django.apps import AppConfig


class CaretakeraddConfig(AppConfig):
    name = 'caretakeradd'
