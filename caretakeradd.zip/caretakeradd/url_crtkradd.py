from  django.conf.urls import url,include
from caretakeradd import views


urlpatterns = [
     url(r'^$', views.add,name='add'),
     url('viewcrtkr/' ,views.viewcrtkr,name='viewcrtkr' ),
 ]