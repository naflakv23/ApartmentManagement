from django.shortcuts import render
from caretakeradd.models import Addcaretaker
# Create your views here.
def add(request):
    if request.method == "POST":
        obj =  Addcaretaker()

        obj.aptname = request.POST.get("apname")
        obj.address = request.POST.get("name")
        obj.flatcount = request.POST.get("Gender")
        obj.name = request.POST.get("name")
        obj.mailid = request.POST.get("email")
        obj.contact = request.POST.get("contact")


        obj.save()
    return render(request,'caretakeradd/caretakeradd.html')
def viewcrtkr(request):
    objlist = Addcaretaker.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request, 'caretakeradd/viewcrtkr.html',context)